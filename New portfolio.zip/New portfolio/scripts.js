document.addEventListener("DOMContentLoaded", function() {
    console.log("Welcome to Shubham Yadav's Portfolio!");
});
